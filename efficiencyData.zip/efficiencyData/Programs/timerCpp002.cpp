/* timerCpp002.cpp */
/* Very simple C++ Test for timeing experiments */
/* gcc timerCpp002.cpp -o timerCpp002 */

#include <stdio.h>

int main (int argc, char *argv[]){
	//Do a bunch of arbitary functions
	int x = 0;
	int y = 0;
	y = y+1;
	x = y*2;
	printf("Timer Test 00%d", x);
	return 0;
}