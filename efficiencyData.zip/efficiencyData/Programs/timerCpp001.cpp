/* timerCpp001.cpp */
/* Very simple C++ Test for timeing experiments */
/* gcc timerCpp001.cpp -0 timerCpp001 */

#include <stdio.h>

int main (int argc, char *argv[]){
	printf("Timer Test 001");
	return 0;
}