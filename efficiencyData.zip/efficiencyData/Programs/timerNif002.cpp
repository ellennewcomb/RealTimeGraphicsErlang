/* timerNif002.cpp */
/* Very basic Nif for the timer experiment. Requires timerErl002.erl */
/*export ERL_ROOT=/usr/lib/erlang
gcc -fPIC -shared -o timerNif002.so timerNif002.cpp -I $ERL_ROOT*/

#include "erl_nif.h"

static ERL_NIF_TERM timeTest (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[])
{
	int x = 0;
	int y = 0;
	y = y+1;
	x = y*2;
	char string[15] = "Timer Test 002";
	char c = x + '0';
	string[13] = c;
	return enif_make_string(env, string, ERL_NIF_LATIN1);
}

static ErlNifFunc nif_funcs[] =
{
	{"timeTest", 0, timeTest}
};

ERL_NIF_INIT(timerErl002, nif_funcs, NULL, NULL, NULL, NULL)