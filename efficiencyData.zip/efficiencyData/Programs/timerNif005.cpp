/* timerNif005.cpp
This is the same as sdlNif001.cpp but cleaned up considerably
export ERL_ROOT=/usr/lib/erlang
gcc -fPIC -shared -o timerNif005.so timerNif005.cpp -I $ERL_ROOT -lSDL -lstdc++*/

#include "erl_nif.h"
#include <SDL/SDL.h>
#include <vector>
#include <iostream>
#include <cstring>
#include <fstream>

#define maxBuffLen 1024

/*Global variables
---------------------------------------------------------------------------------------------------------------------------------------*/

/*Array for storing surfaces in order to access them from an Erlang call.*/
std::vector<SDL_Surface*> surfaceArray;

/*Array for storing the names associated with surfaces*/
std::vector<std::string> surfaceNames;

/*Private Functions
-------------------------------------------------------------------------------------------------------------------------------------------*/
/**
* Looks up surface index
* @param surface name (string)
* @return Index int if found, or -1 if not found.
**/
int surfaceIndex(std::string surfaceName){
	//Returns the index of a surfaceName in surfaceNames
	int i = 0;
	while(i<surfaceNames.size()){
		//If the surfaceName exists in surfaceNames return the index
		const char* surfaceNamesValue = surfaceNames[i].c_str();
		const char* surfaceNameValue = surfaceName.c_str();
		if(std::strcmp(surfaceNamesValue,surfaceNameValue)==0){
			return i;
		}
		i++;
	}
	//If surface not found return -1
	return (-1);
}

/*NIF FUNCTIONS 
-------------------------------------------------------------------------------------------------------------------------------------------*/

/**
*	Wrapped SDL_Init function.
*	@params Requires a flag (char*). Is passed as an argument from Erlang.
*	@Return ERL_NIF_TERM A bad argument error, or 0 on success
**/
static ERL_NIF_TERM sdl_Init (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[]){
	char initFlag[maxBuffLen];
	enif_get_string(env, argv[0], initFlag, maxBuffLen, ERL_NIF_LATIN1); //Gets the string passed by the function call and puts it in initFlag.
	if (std::strcmp(initFlag, "SDL_INIT_VIDEO") == 0){
		SDL_Init(SDL_INIT_VIDEO);
		return enif_make_int(env,0); /*exit code, process terminated correctly*/
	}
	else{
		/* Flag not recognised, process not terminated correctly*/
		return enif_make_string(env, "Init Flag not recognised, Init terminated" , ERL_NIF_LATIN1);
	}
}

/**
*	Wrapped SDL_Quit function.
*	@params None.
*	@Return ERL_NIF_TERM 0 on success
**/
static ERL_NIF_TERM sdl_Quit (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[]){
	SDL_Quit();
	return enif_make_int(env,0); /*exit code*/
}

/**
*	Wrapped SDL_CreateSurface function.
*	@params Requires a surface name (char*). Is passed as an argument from Erlang.
*	@Return ERL_NIF_TERM A bad argument error, an error if the surface already exists, or 0 on success
**/
static ERL_NIF_TERM sdl_CreateSurface (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[]){
	char surfaceName[maxBuffLen];
	if(!enif_get_string(env, argv[0], surfaceName, maxBuffLen, ERL_NIF_LATIN1)){
		return enif_make_badarg(env);
	}
	std::string surfaceString(surfaceName);
	//If the surfaceName already exists throw a wobbly
	int i = surfaceIndex(surfaceString);
	if(i>=0){
		return enif_make_string(env, "The surface name specified already exists, new surface not created" , ERL_NIF_LATIN1);
	}
	surfaceNames.push_back(surfaceString);
	SDL_Surface* newSurface = new SDL_Surface();
	surfaceArray.push_back(newSurface);
	
	return enif_make_int(env,0); /*exit code*/
}

/**
*	Wrapped SDL_SetVideoMode function.
*	@params Requires integer values (width, height, bits-per-pixel), a flag (char*) and a surface. Passed as an argument from Erlang.
*	@Return ERL_NIF_TERM A bad argument error, Surface not found error, or 0 on success
**/
static ERL_NIF_TERM sdl_SetVideoMode (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[]){
	int width, height, bits;
	char flag[maxBuffLen];
	char surfaceName [maxBuffLen];
	//If width, height and bits passed are not integers throw an error
	if (!enif_get_int(env, argv[0], &width) || !enif_get_int(env, argv[1], &height) || !enif_get_int(env, argv[2], &bits))
	{
		return enif_make_badarg(env);
	}
	//If flag passed is not a string throw an error
	if(!enif_get_string(env, argv[3], flag, maxBuffLen, ERL_NIF_LATIN1)){
		//If fileName passed is not a string throw an error
		return enif_make_badarg(env);
	}
	
	//If surface passed is not a string throw an error
	if(!enif_get_string(env, argv[4], surfaceName, maxBuffLen, ERL_NIF_LATIN1)){
		return enif_make_badarg(env);
	}
	std::string surfaceString(surfaceName);
	
	//If surface doesn't exist throw an error
	int i = surfaceIndex(surfaceString);
	if(i<0){
		return enif_make_string(env, "SurfaceIndex returned <0 in sdl_CreateRGBSurface" , ERL_NIF_LATIN1);
	}
	SDL_Surface* surface = surfaceArray[i];
	
	//Check flag
	if (std::strcmp(flag, "SDL_SWSURFACE") == 0){
		
		surface = SDL_SetVideoMode(width, height, bits, SDL_SWSURFACE);	
		surfaceArray[i]=surface;
		
		return enif_make_int(env,0); /*exit code, process terminated correctly*/
	}
	else{
		/* Flag not recognised, process not terminated correctly*/
		return enif_make_string(env, "Flag not recognised, sdl_SetVideoMode terminated" , ERL_NIF_LATIN1);
	}
}

/**
*	Wrapped SDL_LoadBMP function.
*	@params Requires the name of the file to load (char*), and a surface to load into. Are passed as an argument from Erlang.
*	@Return ERL_NIF_TERM A bad argument error, surface not found error, or 0 on success
**/
static ERL_NIF_TERM sdl_LoadBMP (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[]){
	char fileName[maxBuffLen];
	char surfaceName[maxBuffLen];
	if(!enif_get_string(env, argv[0], fileName, maxBuffLen, ERL_NIF_LATIN1)){
		//If fileName passed is not a string throw an error
		return enif_make_badarg(env);
	}
	if(!enif_get_string(env, argv[1], surfaceName, maxBuffLen, ERL_NIF_LATIN1)){
		//If surfaceName passed is not a string throw an error
		return enif_make_badarg(env);
	}
	//If surfaceName doesn't exist throw an error
	std::string surfaceString(surfaceName);
	int i = surfaceIndex(surfaceString);
	if(i<0){
		return enif_make_string(env, "SurfaceIndex<0 in sdl_LoadBMP" , ERL_NIF_LATIN1);
	}
	//Otherwise load the bmp into the surface	

	SDL_Surface* surface = surfaceArray[i];
	
 	surface = SDL_LoadBMP(fileName);
	surfaceArray[i] = surface;
	
	if(surface==NULL){
		return enif_make_string(env, "LOAD BMP ERRROR ", ERL_NIF_LATIN1);
	}
	return enif_make_int(env,0); /*exit code*/
}

/**
*	Wrapped SDL_BlitSurface function.
*	@params Requires a surface to blit from, flags for clipping and cropping, and a surface to blit to (surface from, Flag, surface to, Flag). 
*		Are passed as an argument from Erlang.
*	@Return ERL_NIF_TERM A bad argument error, an error if either surface doesn't exist, or 0 on success
**/
static ERL_NIF_TERM sdl_BlitSurface (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[]){
	char primarySurfaceName[maxBuffLen]; // move from
	char secondarySurfaceName[maxBuffLen]; // move into
	char flag1[maxBuffLen];
	char flag2[maxBuffLen];
	
	//If any of the arguments passed are not strings throw an error
	if(!enif_get_string(env, argv[0], primarySurfaceName, maxBuffLen, ERL_NIF_LATIN1) || !enif_get_string(env, argv[1], flag1, maxBuffLen, ERL_NIF_LATIN1) || !enif_get_string(env, argv[2], secondarySurfaceName, maxBuffLen, ERL_NIF_LATIN1) || !enif_get_string(env, argv[3], flag2, maxBuffLen, ERL_NIF_LATIN1)){
		return enif_make_badarg(env);
	}
	//Check if our surfaces exist
	std::string primSurfaceString(primarySurfaceName);
	std::string secSurfaceString(secondarySurfaceName);
	int pindex = surfaceIndex(primSurfaceString);
	int sindex = surfaceIndex(secSurfaceString);
	
	// If surface doesnt exist then error
	if(pindex <0  || sindex <0 ){
		return enif_make_string(env, "SurfaceIndex returned <0 in sdl_BlitSurface", ERL_NIF_LATIN1);
	}

	SDL_Surface* primarySurface = surfaceArray[pindex];
	SDL_Surface* secondarySurface = surfaceArray[sindex];
	
	//Check our flags
	if (std::strcmp(flag1, "NULL") == 0 && std::strcmp(flag2, "NULL")==0){
		
		SDL_BlitSurface(primarySurface, NULL, secondarySurface, NULL);
		surfaceArray[pindex] = primarySurface;
		surfaceArray[sindex] = secondarySurface;
		
		return enif_make_int(env,0); /*exit code, process terminated correctly*/
	}
	else{
		/* Flag not recognised, process not terminated correctly*/
		return enif_make_string(env, "A Flag is not recognised, BlitSurface terminated" , ERL_NIF_LATIN1);
	}
}

/**
*	Wrapped SDL_Flip function.
*	@params Requires the name of the surface to flip (char*). Is passed as an argument from Erlang.
*	@Return ERL_NIF_TERM A bad argument error, a surface not found error, or 0 on success
**/
static ERL_NIF_TERM sdl_Flip (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[]){
	char surfaceName[maxBuffLen];
	if(!enif_get_string(env, argv[0], surfaceName, maxBuffLen, ERL_NIF_LATIN1)){
		//If argument passed is not a string throw an error
		return enif_make_badarg(env);
	}
	//If surfaceName doesn't exist throw an error
	std::string surfaceString(surfaceName);
	int i = surfaceIndex(surfaceString);
	if(i<0){
		return enif_make_string(env, "SurfaceIndex returned <0 in sdl_Flip" , ERL_NIF_LATIN1);
	}
	SDL_Surface* surface = surfaceArray[i];
	SDL_Flip(surface);
	return enif_make_int(env,0); /*exit code*/	
}

/**
*	Wrapped SDL_FreeSurface function.
*	@params Requires the name of the surface to free. Is passed as an argument from Erlang.
*	@Return ERL_NIF_TERM A bad argument error, a string error if the surface is not found, or 0 on success
**/
static ERL_NIF_TERM sdl_FreeSurface (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[]){
	char surfaceName[maxBuffLen];
	if(!enif_get_string(env, argv[0], surfaceName, maxBuffLen, ERL_NIF_LATIN1)){
		return enif_make_badarg(env);
	}
	std::string surfaceString(surfaceName);
	int index = surfaceIndex(surfaceString);
	
	if(index<0){
		return enif_make_string(env, "SurfaceIndex returned <0 in sdl_FreeSurface" , ERL_NIF_LATIN1);
	}
	
	//Free the surface
	SDL_FreeSurface(surfaceArray[index]);
	//Erase the surface and it's name from the arrays
	surfaceArray.erase(surfaceArray.begin()+index);
	surfaceNames.erase(surfaceNames.begin() + index);
	return enif_make_int(env, 0); /*Exit Code*/
}

/**
*	An array of the functions (as they are referred to by Erlang, their arity, and the function name in cpp)
**/
static ErlNifFunc nif_funcs[] = {
	{"sdl_Init", 1, sdl_Init},
	{"sdl_Quit", 0, sdl_Quit},
	{"sdl_CreateSurface",1,sdl_CreateSurface},
	{"sdl_SetVideoMode",5,sdl_SetVideoMode},
	{"sdl_LoadBMP",2,sdl_LoadBMP},
	{"sdl_BlitSurface",4,sdl_BlitSurface},
	{"sdl_Flip",1,sdl_Flip},
	{"sdl_FreeSurface",1,sdl_FreeSurface},
};

/**
*	Variable for initialising the NIFs
**/
ERL_NIF_INIT(timerErl005, nif_funcs, NULL, NULL, NULL, NULL)
