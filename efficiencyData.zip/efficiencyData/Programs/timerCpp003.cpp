/* timerCpp003.cpp */
/* Very simple C++ Test for timing experiments. This one takes a parameter */
/* gcc timerCpp003.cpp -o timerCpp003 */

#include <stdio.h>

int main (int argc, char *argv[]){
	char y = argv[1][0];
	int x = y - '0';
	printf("Timer Test 00%d", x);
	return 0;
}