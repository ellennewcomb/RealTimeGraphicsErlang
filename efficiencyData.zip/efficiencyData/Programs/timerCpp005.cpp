/* timerCpp005.cpp */
/* Very simple C++ Test for timing experiments. Starting to use SDL functions */
/* gcc timerCpp005.cpp -o timerCpp005 -lSDL */

#include <stdio.h>
#include <SDL/SDL.h>

int main (int argc, char* args[])
{
	//The images 
	SDL_Surface* hello = NULL; 
	SDL_Surface* screen = NULL;
	
	SDL_Init( SDL_INIT_VIDEO );
	
	screen = SDL_SetVideoMode( 640, 480,32, SDL_SWSURFACE);
	
	hello = SDL_LoadBMP("hello.bmp");
	
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	
	SDL_FreeSurface(hello);
	
	SDL_Quit();
	
	return 0;
}