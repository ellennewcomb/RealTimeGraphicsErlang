-module(timerErl006).
-export([start/0, sdl_Init/1, sdl_Quit/0, sdl_CreateSurface/1, sdl_SetVideoMode/5, sdl_LoadBMP/2, sdl_BlitSurface/4, sdl_Flip/1, sdl_FreeSurface/1, timeTest/0]).

-on_load(start/0).

%Erlang for calling very simple SDL function.
%This is the same as sdlErlang001.erl, but cleaned up a little

start() ->
	erlang:load_nif("./timerNif006",0).

sdl_Init(_flags) ->
	%call the function for initialising sdl with _flags
	"Nif not loaded - sdl_Init()".

sdl_Quit()->
	%Calls the sdl_Quit function which releases all surfaces and whatnots
	"Nif not loaded - sdl_Quit".

sdl_CreateSurface(_name) ->
	%NEW FUNCTION FOR ERLANG - Create a surface and set it to null
	"Nif not loaded - sdl_CreateSurface".

sdl_SetVideoMode(_width,_height,_bpp,_flags, _surface) ->
	%Call the function for setting the video
	"Nif not loaded - sdl_SetVideoMode()".
	
sdl_LoadBMP(_fileName,_surface) ->
	%Call the function for loading a bmp file
	"Nif not loaded - sdl_LoadBMP()".

sdl_BlitSurface(_source,_sourceRect,_surface,_position) ->
	%Call the function SDL_BlitSurface (here used to set the bmp to a surface)
	"Nif not loaded - sdl_BlitSurface()".

sdl_Flip(_surface) ->
	%Calls the SDL_Flip function to swap screen buffers
	"Nif not loaded - sdl_Flip()".

sdl_FreeSurface(_surface) ->
	%Calls the function to free _surface from use
	"Nif not loaded - sdl_FreeSurface".
	
timeTest() ->
	sdl_Init("SDL_INIT_VIDEO"),
	sdl_CreateSurface("screen"),
	sdl_CreateSurface("hello"),
	sdl_SetVideoMode(640, 480,32, "SDL_SWSURFACE", "screen"),
	%load and swap the bmp 20 times
	%done by hand to conserve proximity to c++
	sdl_LoadBMP("colourFlash001.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash002.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash001.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash002.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash001.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash002.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash001.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash002.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash001.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash002.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash001.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash002.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash001.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash002.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash001.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash002.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash001.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash002.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash001.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),
	sdl_LoadBMP("colourFlash002.bmp","hello"),
	sdl_BlitSurface("hello","NULL","screen","NULL"),
	sdl_Flip("screen"),	
	%----------------------
	sdl_FreeSurface("screen"),
	sdl_Quit().
	
	
