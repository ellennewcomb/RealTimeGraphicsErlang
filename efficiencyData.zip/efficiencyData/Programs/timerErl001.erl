-module(timerErl001).
-export([start/0, timeTest/0]).

%Test 001 for timer experiments

-on_load(start/0).

start() ->
	erlang:load_nif("./timerNif001",0).
	
timeTest() ->
	"Nif not loaded - timeTest()".