-module(timerErl004).
-export([start/0, timeTest/1]).

%Test 004 for timer experiments, includes a parameter

-on_load(start/0).

start() ->
	erlang:load_nif("./timerNif004",0).
	
timeTest(_X) ->
	"Nif not loaded - timeTest()".