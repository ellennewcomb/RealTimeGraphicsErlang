-module(timerErl002).
-export([start/0, timeTest/0]).

%Test 002 for timer experiments

-on_load(start/0).

start() ->
	erlang:load_nif("./timerNif002",0).
	
timeTest() ->
	"Nif not loaded - timeTest()".