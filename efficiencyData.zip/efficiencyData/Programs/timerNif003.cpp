/* timerNif003.cpp */
/* Very basic Nif for the timer experiment. Requires timerErl003.erl */
/*export ERL_ROOT=/usr/lib/erlang
gcc -fPIC -shared -o timerNif003.so timerNif003.cpp -I $ERL_ROOT*/

#include "erl_nif.h"

static ERL_NIF_TERM timeTest (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[])
{
	int x;
	if (!enif_get_int(env, argv[0], &x))
	{
		return enif_make_badarg(env);
	}
	char string[15] = "Timer Test 003";
	char c = x + '0';
	string[13] = c;
	return enif_make_string(env, string, ERL_NIF_LATIN1);
}

static ErlNifFunc nif_funcs[] =
{
	{"timeTest", 1, timeTest}
};

ERL_NIF_INIT(timerErl003, nif_funcs, NULL, NULL, NULL, NULL)