/* timerCpp007.cpp */
/* Very simple C++ Test for timing experiments. Comparing while loops and recursion */
/* gcc timerCpp007.cpp -o timerCpp007 -lSDL */

#include <stdio.h>
#include <cstdlib>
#include <SDL/SDL.h>

int main (int argc, char* argv[])
{
	char * y = argv[1];
	int x = std::atoi(y);
	
	SDL_Surface* hello = NULL; 
	SDL_Surface* screen = NULL;
	
	SDL_Init( SDL_INIT_VIDEO );
	
	screen = SDL_SetVideoMode( 640, 480,32, SDL_SWSURFACE);
	
	while(x>0){
		hello = SDL_LoadBMP("colourFlash001.bmp");
		SDL_BlitSurface(hello, NULL, screen, NULL);
		SDL_Flip(screen);
		hello = SDL_LoadBMP("colourFlash002.bmp");
		SDL_BlitSurface(hello, NULL, screen, NULL);
		SDL_Flip(screen);
		x=x-1;
	}
	
	SDL_FreeSurface(hello);
	
	SDL_Quit();
	
	return 0;
}