/* timerCpp006.cpp */
/* Very simple C++ Test for timing experiments. Starting to use SDL functions */
/* gcc timerCpp006.cpp -o timerCpp006 -lSDL */

#include <stdio.h>
#include <SDL/SDL.h>

int main (int argc, char* args[])
{
	//The images 
	SDL_Surface* hello = NULL; 
	SDL_Surface* screen = NULL;
	
	SDL_Init( SDL_INIT_VIDEO );
	
	screen = SDL_SetVideoMode( 640, 480,32, SDL_SWSURFACE);
	
	//Load annd flip between two bmps 20 times. 
	//This is done without loops in order to maintain proximity to the Erlang.
	hello = SDL_LoadBMP("colourFlash001.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash002.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash001.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash002.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash001.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash002.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash001.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash002.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash001.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash002.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash001.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash002.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash001.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash002.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash001.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash002.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash001.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash002.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash001.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	hello = SDL_LoadBMP("colourFlash002.bmp");
	SDL_BlitSurface(hello, NULL, screen, NULL);
	SDL_Flip(screen);
	
	SDL_FreeSurface(hello);
	
	SDL_Quit();
	
	return 0;
}