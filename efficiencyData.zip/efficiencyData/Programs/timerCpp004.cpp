/* timerCpp004.cpp */
/* Very simple C++ Test for timing experiments. This one takes a parameter and computes it's factorial */
/* gcc timerCpp004.cpp -o timerCpp004 */

#include <stdio.h>
#include <cstdlib>

int main (int argc, char *argv[]){
	char* y = argv[1];
	int x = std::atoi(y);
	int f = x;
	while(x>1){
		x=x-1;
		f=f*x;
	}
	printf("Timer Test 0%d", f);
	return 0;
}