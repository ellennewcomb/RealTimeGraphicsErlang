/* timerNif001.cpp */
/* Very basic Nif for the timer experiment. Requires timerErl001.erl */
/*export ERL_ROOT=/usr/lib/erlang
gcc -fPIC -shared -o timerNif001.so timerNif001.cpp -I $ERL_ROOT*/

#include "erl_nif.h"

static ERL_NIF_TERM timeTest (ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[])
{
	return enif_make_string(env, "Timer Test 001", ERL_NIF_LATIN1);
}

static ErlNifFunc nif_funcs[] =
{
	{"timeTest", 0, timeTest}
};

ERL_NIF_INIT(timerErl001, nif_funcs, NULL, NULL, NULL, NULL)